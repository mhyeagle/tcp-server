make clean
make
/home/w/script/rpmbuild2  threadpool.spec 1.0.0 2
#rsync -av libtdbm-1.0.0-2.x86_64.rpm  10.168.9.235::rpm-root/
